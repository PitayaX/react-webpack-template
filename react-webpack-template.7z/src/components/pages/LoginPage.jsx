import React from 'react'

const LoginHandler =React.createClass({
  render () {
    return (
      <p> Hello login page</p>
    )
  }
})
export  default LoginHandler
