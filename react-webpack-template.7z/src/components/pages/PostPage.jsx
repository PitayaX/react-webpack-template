import React from 'react'

const RootHandler =React.createClass({
  render () {
    return (
      <p> Hello Post</p>
    )
  }
})
export default RootHandler
