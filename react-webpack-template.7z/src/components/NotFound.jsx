import React, { PropTypes } from 'react'

const NotFound= React.createClass({
  render () {
    return (
      <h1>Sorry, this is 404!</h1>
    )
  }
})
export default NotFound
