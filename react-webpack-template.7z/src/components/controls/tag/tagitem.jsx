import React, { propTypes } from 'react'

const TagItem= React.createClass({
  propTypes: {
    tagName: React.PropTypes.string.isRequired,
    tagId: React.PropTypes.number,
    onClick: React.PropTypes.func
  },
  handleClick () {
    this.props.onClick(this.props.tagId)
  },
  render () {
    return (
      <li className="tag-item">
        <a className="category"  href="javascript:void(null);" onClick={this.handleClick}>
          {this.props.tagName}
        </a>
      </li>
    )
  }
})
export default TagItem
