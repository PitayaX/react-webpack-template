import React, { propTypes } from 'react'
import TagItem from './tagitem'

const TagList= React.createClass({
  propTypes: {
    data: React.PropTypes.array,
    onClick: React.PropTypes.func
  },
  getDefaultProps () {
    return {
      data: [],
      currentSelectedTagId: 1
    }
  },
  handleClick (tagId) {
    this.props.onClick(tagId)
  },
  render () {
    const  _tagList = this.props.data.map(function (tag, index) {
        return (
          <TagItem tagId={tag.id} tagName={tag.tagName} onClick={this.handleClick} />
        )
      }, this)
    return (

      <div className="tag-list">
        <ul>
          {_tagList}
        </ul>
      </div>
    )
  }
})
export default TagList
