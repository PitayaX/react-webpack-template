import React from 'react'

const HomeHandler= React.createClass({

  render () {
    return (
      <div className="home">this is home page</div>
    )
  }
})
export default HomeHandler
