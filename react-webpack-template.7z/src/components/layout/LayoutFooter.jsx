import React from 'react'

const Footer=React.createClass({

  render () {
    return (
      <div>
        <p>Copyright@PitayaX</p>
      </div>      
    )
  }
})
export default Footer
