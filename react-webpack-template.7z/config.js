export default {
  webpackDevPort: 3000,
  publishPath: 'D:\\www\\assetsss', // ignore it when developing
  aliasPath: {
    'less': 'E:\\nodeworkspace\\pitayax-fork\\react-webpack-template\\src\\less' // alias path for less
  }
}
